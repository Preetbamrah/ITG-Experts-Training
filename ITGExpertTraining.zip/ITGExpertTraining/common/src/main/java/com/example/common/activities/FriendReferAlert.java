package com.example.common.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.common.R;

public class FriendReferAlert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_refer_alert);
    }
}
